package jfxtras.scene.control;

import com.sun.javafx.scene.control.behavior.BehaviorBase;

/**
 *
 * @author Goran Lochert
 * 
 */
public class DeckPaneXBehavior extends BehaviorBase<DeckPaneX> {

    public DeckPaneXBehavior(DeckPaneX deckPane) {
        super(deckPane);
    }
}
