/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jfxtras.scene.control;

import com.sun.javafx.scene.control.behavior.BehaviorBase;

/**
 *
 * @author Goran Lochert
 */
public class PagerXBehavior extends BehaviorBase<PagerX> {

    public PagerXBehavior(PagerX pager) {
        super(pager);
    }
    
    
}
