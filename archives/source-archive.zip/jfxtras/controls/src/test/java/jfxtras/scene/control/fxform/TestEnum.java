package jfxtras.scene.control.fxform;

import org.junit.Ignore;

/**
 * Model enum used for testing.
 * <p/>
 * User: Antoine Mischler <antoine@dooapp.com>
 * Date: 12/09/11
 * Time: 17:05
 */
@Ignore
public enum TestEnum {
}
