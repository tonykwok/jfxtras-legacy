/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jfxtras.pdf;

import com.sun.pdfview.PDFPage;
import java.awt.Image;

/**
 *
 * @author jimclarke
 */
public interface ImageListener {
    public void imageLoaded(Image img);
}
