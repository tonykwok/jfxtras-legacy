/**
 * Copyright (c) 2008-2010, JFXtras Group
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of JFXtras nor the names of its contributors may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.jfxtras;

import org.apache.maven.artifact.Artifact;
import org.apache.maven.artifact.installer.ArtifactInstallationException;
import org.apache.maven.model.Model;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.project.artifact.ProjectArtifactMetadata;
import org.sonatype.plexus.component.bundlepublisher.model.BundleArtifact;
import org.sonatype.plexus.component.bundlepublisher.model.BundleDescriptor;

import java.io.File;
import java.io.IOException;

/**
 * Installs the JavaFX SDK jars to the local repository.<p/>
 * This location of the JavaFX SDK is looked up using those strategies:
 * <ul>
 * <li>Configuration: {@link #javaFxHomeDir}</li>
 * <li>System properties:
 * <ul>
 * <li>JAVAFX_HOME</li>
 * <li>FX_HOME</li>
 * </ul>
 * </li>
 * <li>Default install location
 * <ul>
 * <li>Linux: /opt/javafx-sdk1.3
 * <li>Mac: /Library/JavaFX/Home
 * <li>Windows: C:\Program Files\JavaFX\javafx-sdk1.3
 * </ul>
 * </li>
 * </ul>
 * <p/>
 * Sample usage:<br/>
 * <code>mvn org.jfxtras:javafx-maven-plugin:install-sdk-jars -Djavafx.home=&lt;path/to/javafx/sdk&gt;</code>
 *
 * @author Johannes Schneider (<a href=mailto:js@cedarsoft.com>js@cedarsoft.com</a>)
 * @goal install-sdk-jars
 * @requiresProject false
 */
public class InstallSdkToLocalRepository extends AbstractJavaFxMojo {
  @Override
  protected void execute( File sdkInstallDir, BundleDescriptor descriptor, String version ) throws Exception {
    installJars( sdkInstallDir, descriptor, version );
  }

  private void installJars( File sdkInstallDir, BundleDescriptor descriptor, String defaultVersion ) throws MojoExecutionException, ArtifactInstallationException, IOException {
    for ( BundleArtifact bundleArtifact : descriptor.getArtifacts() ) {
      File jar = new File( sdkInstallDir, bundleArtifact.getLocation() );
      if ( !jar.exists() ) {
        throw new MojoExecutionException( "File not found at <" + jar.getAbsolutePath() + ">" );
      }

      String groupId = bundleArtifact.getGroupId() != null ? bundleArtifact.getGroupId() : descriptor.getDefaults().getGroupId();
      String artifactId = bundleArtifact.getArtifactId();
      String version = bundleArtifact.getVersion() != null ? bundleArtifact.getVersion() : defaultVersion;

      Artifact artifact = factory.createArtifact( groupId, artifactId, version, "compile", "jar" );

      Model model = createModel( groupId, artifactId, version );
      File pom = createTemporaryPom( model );
      try {
        artifact.setFile( jar );
        artifact.addMetadata( new ProjectArtifactMetadata( artifact, pom ) );
        installer.install( jar, artifact, localRepository );
      } finally {
        pom.delete();
      }
    }
  }

  protected Model createModel( String groupId, String artifactId, String version ) {
    Model pom = new Model();

    pom.setModelVersion( "4.0.0" );
    pom.setGroupId( groupId );
    pom.setArtifactId( artifactId );
    pom.setVersion( version );
    pom.setPackaging( "jar" );

    return pom;
  }

}
