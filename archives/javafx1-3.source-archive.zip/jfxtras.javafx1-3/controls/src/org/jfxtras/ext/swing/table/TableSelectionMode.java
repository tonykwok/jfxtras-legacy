/*
 * Copyright (c) 2008-2010, JFXtras Group
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of JFXtras nor the names of its contributors may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.jfxtras.ext.swing.table;

/**
 * Enumeration of table selection modes.
 *
 * @profile desktop
 * @author John Freeman
 */
public enum TableSelectionMode {
    /**
     * Individual cells may be selected.
     */
    CELL {
        @Override
        public TableSelectionMode add(TableSelectionMode mode) {
            return CELL;
        }

        @Override
        public TableSelectionMode subtract(TableSelectionMode mode) {
            switch(mode) {
                case CELL:
                    return NONE;
                case COLUMN:
                    return ROW;
                case ROW:
                    return COLUMN;
                default:
                    return CELL;
            }
        }
    },

    /**
     * Only complete columns can be selected.
     */
    COLUMN {
        @Override
        public TableSelectionMode add(TableSelectionMode mode) {
            switch(mode) {
                case CELL:
                case ROW:
                    return CELL;
                default:
                    return COLUMN;
            }
        }

        @Override
        public TableSelectionMode subtract(TableSelectionMode mode) {
            switch(mode) {
                case CELL:
                case COLUMN:
                    return NONE;
                default:
                    return COLUMN;
            }
        }
    },

    /**
     * Only complete rows can be selected.
     */
    ROW {
        @Override
        public TableSelectionMode add(TableSelectionMode mode) {
            switch(mode) {
                case CELL:
                case COLUMN:
                    return CELL;
                default:
                    return ROW;
            }
        }

        @Override
        public TableSelectionMode subtract(TableSelectionMode mode) {
            switch(mode) {
                case CELL:
                case ROW:
                    return NONE;
                default:
                    return ROW;
            }
        }
    },

    /**
     * Selection is disabled.
     */
    NONE {
        @Override
        public TableSelectionMode add(TableSelectionMode mode) {
            return mode == null ? NONE : mode;
        }

        @Override
        public TableSelectionMode subtract(TableSelectionMode mode) {
            return NONE;
        }
    };

    /**
     * Returns the combination of the current selection mode with specified additional selection mode. Combining
     * row and column selection results in cell selection mode.
     *
     * @param mode to add
     * @return the combination of the current selection mode with specified additional selection mode.
     */
    public abstract TableSelectionMode add(TableSelectionMode mode);

    /**
     * Returns the current selection mode with specified selection mode removed. Subtracting row or column selection
     * mode from cell selection mode results in column and row selection mode accordingly.
     *
     * @param mode to subtract
     * @return the current selection mode with specified selection mode removed.
     */
    public abstract TableSelectionMode subtract(TableSelectionMode mode);
}
